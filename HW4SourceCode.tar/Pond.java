/**
* Pond
*
* A pond for fish to live in
*/ 

public class Pond
{
  public double[] findNearestSmallFish(double x, double y)
  {
    double[] location = {4.0, 8.0};
    return location;
  }

  public double[] findNearestBigFish(double x, double y)
  {
    double[] location = {2.0, 1.0};
    return location;
  }

  public double[] findNearestPlant(double x, double y)
  {
    double[] location = {0.0, 0.0};
    return location;
  }
}
